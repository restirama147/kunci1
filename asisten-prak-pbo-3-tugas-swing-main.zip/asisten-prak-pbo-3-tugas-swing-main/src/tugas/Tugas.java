package tugas;

/**
 *
 * @author rafli
 */
public class Tugas {
    public static void main(String[] args) {
        new LoginPage();
        new BalokPage();
    }
    
}
